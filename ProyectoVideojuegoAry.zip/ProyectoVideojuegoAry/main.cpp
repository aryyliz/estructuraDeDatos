#include <iostream>
#include "monstruo.h"
#include "cuarto.h"
#include "catalog.h"
#include "dungeon.h"
#include "jugadora.h"

#define NUM_CUARTOS 20
 int main(){
    Catalog    miCatalogo; //objeto de la clase Catalogo
    Dungeon    miDungeon;  //objeto de la clase Dungeon

    if(!miCatalogo.loadFromCSV("monsters.csv")){ //se intenta cargar el archivo csv en el objeto miCatalogo
        std::cout << "No se pudo crear el catálogo" << std::endl; //si no se puede, imprime un error
        return 0; //regresa 0
    }

    std::cout << "Creando Dungeon..." << std::endl;

    for(int c = 0; c < NUM_CUARTOS; c ++){ //ciclo for que define 
        Monstruo *pMonstruo = nullptr, copiaMonstruo; //apuntador a Monster y una variable copiaMonstruo de tipo Monster
        pMonstruo = miCatalogo.randomMonstruo(); //obtiene un monstruo aleatorio
        if(!pMonstruo){ //si no se puede, imprime un error
            std::cout << "No se pudo obtener un monstruo del catálogo" << std::endl;
            return 0; //regresa 0
        }

        copiaMonstruo = *pMonstruo; //se copia el monstruo en la variable copiaMonstruo
        //se crea una habitación en el objeto miDungeon con el monstruo copiado
        if(!miDungeon.createRoom(copiaMonstruo)){ //si no se puede, imprime error
            std::cout << "No se pudo insertar cuarto con monstruo al calabozo" << std::endl;
            return 0; //y regresa 0
        }
    }
    //después de crear los cuartos
    miDungeon.imprimir(); //se ejecuta la función imprimeCuartos del objeto miDungeon 

    return 0; //termina el programa
}