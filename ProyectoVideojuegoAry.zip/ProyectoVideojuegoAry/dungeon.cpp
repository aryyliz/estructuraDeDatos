#include "dungeon.h"

Dungeon::Dungeon() : cuartos() {}

Dungeon::~Dungeon() {
    cuartos.borrar();
}

void Dungeon::imprimir(){
    cuartos.imprime();
}

bool Dungeon::createRoom(Monstruo& monstruo) {
    Cuarto nuevo(monstruo);
    return this->cuartos.insertaFinal(nuevo);
}
