#pragma once
#include <iostream>
#include "cuarto.h"
#include "dobleListaLigadaT.h"

class Dungeon{
public:
    Dungeon();
    ~Dungeon();
    void imprimir();
    bool createRoom(Monstruo& monstruo);

private:
    ListaDual<Cuarto> cuartos;
};