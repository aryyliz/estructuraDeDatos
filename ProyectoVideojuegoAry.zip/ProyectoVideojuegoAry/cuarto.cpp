#include "cuarto.h"

Cuarto::Cuarto() : cuartoMonstruo() {}

Cuarto::Cuarto(Monstruo& monstruo) : cuartoMonstruo(monstruo){}
 
Cuarto::~Cuarto(){
}

std::ostream& operator<<(std::ostream& os, const Cuarto& Cuarto){
    os << "Cuarto con: " << Cuarto.cuartoMonstruo << std::endl;
        return os;
}