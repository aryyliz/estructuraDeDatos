#pragma once

template <typename T>

class Nodo{
public: 
    T dato;
    Nodo<T> *next;
    Nodo<T> *prev;

    Nodo<T>::Nodo(){
    next = nullptr;
    prev = nullptr;
    }

    Nodo<T>::~Nodo();
};
