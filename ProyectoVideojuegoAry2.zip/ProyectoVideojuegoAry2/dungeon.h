#pragma once
#include <iostream>
#include "cuarto.h"
#include "grafo.h"

class Dungeon{
public:
    Dungeon();
    ~Dungeon();
    bool createRoom(unsigned int vertice, Monstruo& monstruo);
    bool createDungeon(const std::string &fileName);
    unsigned int getSize();
    void imprimir();
private:
    Grafo<Cuarto> cuartos;
};