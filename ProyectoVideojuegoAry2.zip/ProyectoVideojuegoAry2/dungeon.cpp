#include "dungeon.h"

Dungeon::Dungeon() : cuartos() {}

Dungeon::~Dungeon() {
    cuartos.borrarGrafo();
}

bool Dungeon::createRoom(unsigned int vertice, Monstruo& monstruo) {
    Cuarto nuevo(monstruo);
    return cuartos.setVertice(vertice, nuevo);
}

bool Dungeon::createDungeon(const std::string &fileName){
    return cuartos.cargarArchivo(fileName);
}

unsigned int Dungeon::getSize(){
    return cuartos.getSize();
}

void Dungeon::imprimir(){
    cuartos.imprimirGrafo();
}