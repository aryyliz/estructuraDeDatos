#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "dobleListaLigadaT.h"


template <typename T>
class Vertice{
public: 
    T dato;
    bool visitado = false;
    ListaDual<unsigned int> arista;
};

template <typename T>
class Grafo{
private: 
    Vertice<T> *vertices;
    unsigned int size;

public: 
    Grafo(){
        vertices = nullptr;
        size = 0;
    }

    ~Grafo(){
        borrarGrafo();
    }

    bool crearGrafo(unsigned int nSize){
        if(nSize == 0 || vertices){
            return false;
        }

        vertices = new(std::nothrow) Vertice<T>[nSize];
        if(!vertices){
            return false;
        }
        size = nSize;
        return true;
    }

    bool insertarArista(unsigned int vert1, unsigned int vert2){
        if(!vertices){
            return false;
        }

        if(vert1 >= size || vert2 >= size){
            return false;
        }
        if(vertices[vert1].arista.buscar(vert2)){
            return false;
        }
        if(!vertices[vert1].arista.insertaFinal(vert2)){
            return false;
        }
        return true;
    }

    bool eliminaArista(unsigned int vert1, unsigned int vert2){
        if(!vertices){
            return false;
        }

        if(vert1 >= size || vert2 >= size){
            return false;
        }
        if(vertices[vert1].arista.busqueda(vert2)){
            return false;
        }
        if(!vertices[vert1].arista.borrarElemento(vert2)){
            return true;
        }
        return false;
    }

    void borrarGrafo(){
        if(vertices){
            delete [] vertices;
            vertices = nullptr;
            size = 0;
        }
    }

    bool cargarArchivo(const std::string& fileName){
        std::ifstream file(fileName);
        std::string line;
        unsigned int nSize = 0, vertice = 0;

        if(!file.is_open()) {
            std::cerr << "Error al abrir el archivo: " << fileName << std::endl; // Cambié 'csv' por 'fileName'
            return false;
        }

        // header (salta a la primera línea)
        if(!getline(file, line)) {
            std::cerr << "El archivo no tiene primera línea" << std::endl;
            file.close();
            return false;
        }

        if(line != "Grafo"){
            file.close();
            return false;
        }

        if(!getline(file, line)){
            std::cerr << "El grafo no tiene tamaño" << std::endl;
            file.close();
            return false;
        }

        if(!isValidNumber(line)){
            std::cerr << "El tamaño del grafo no es numério" << std::endl;
            file.close();
            return false;
        }

        nSize = stoi(line);

        if(nSize <= 0){
            std::cerr << "El tamaño del grafo es incorrecto" << std::endl;
            file.close();
            return false;
        }

        borrarGrafo();

        if(!crearGrafo(nSize)){
            std:: cerr << "No se pudo crear el grafo" << std::endl;
            file.close();
            return false;        
        }

        for(vertice = 0; vertice < nSize; vertice++){
            if(!getline(file, line)){
                std::cerr << "No hay arista" << std::endl;
                file.close();
                return false;
            }

            if(line.length()){
                std::stringstream ss(line);
                std::string cell;
                while(getline(ss, cell,' ')){
                    int fin = 0;
                    if(!isValidNumber(cell)){
                        file.close();
                        return false;
                    }

                    fin = stoi(cell);
                    if(!insertarArista(vertice, fin)){
                        file.close();
                        return false;
                    }
                }
            }
        }

        file.close();
        return true;
    }

    bool guardarArchivo(const std::string& fileName){
        std::ofstream file;

        if(!size){
            return false;
        }

        file.open(fileName, std::ios::out);
        if(!file.is_open()){
            std::cerr << "Error al guardar el archivo: " << fileName << std::endl;
            return false;
        }

        //El encabezado es una palabra
        file << "Grafo\n";
        //Cantidad de vértices
        file << size << "\n";

        //lista a agregar de arista
        for(unsigned int i = 0; i < size; i++){
            ListaDual<unsigned int>::iterator j(nullptr);
            for(j = vertices[i].arista.begin(); j != vertices[i].arista.end(); ++j){
                file << *j << " ";
            }
            file << "\n";
        }

        file.close();

        return true;
    }

    void imprimirGrafo(){
        for(unsigned int i = 0; i < size; i++){
            std::cout << "[" << i << "] " << vertices[i].dato << ": ";
            vertices[i].arista.imprime();
        }
    }

    void DFSrecursivo(unsigned int vertice){
        vertices[vertice].visitado = true;
        std::cout << vertice << " ";
        ListaDual<unsigned int>::iterator i(nullptr);
        for(i = vertices[vertice].arista.begin(); i != vertices[vertice].arista.end(); ++i){
            if(!vertices[*i].visitado){
                DFSrecursivo(*i);
            }
        }
    }

    bool setVertice(const unsigned int vertice, T dato){
        if(!size || vertice >= size){
            return false;
        }

        vertices[vertice].dato = dato;
        return true;
    }
    
    unsigned int getSize(){
        return size;
    }

    bool isValidNumber(const std::string &stg){
        for(int i = 0; i < stg.length(); i++){
            if(!isdigit(stg[i])){
                return false;
            }
        }
        return true;
    }

};